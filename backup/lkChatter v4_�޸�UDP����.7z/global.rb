Thread.abort_on_exception = true

PORT = 2122

require 'log4r'
include Log4r
$log = Logger.new ''
$log.outputters = Outputter.stdout
$log.level = INFO


$queue_keep_alive = Queue.new
$queue_normal_message = Queue.new
$queue_from_user = Queue.new
$queue_device_answer = Queue.new
