require "lib"

window = Gtk::Window.new(Gtk::Window::TOPLEVEL)
window.set_title  "中兴通讯中国移动企业一卡通接口测试工具"
window.border_width = 10
window.signal_connect('delete_event') { Gtk.main_quit }
window.set_size_request(800, 600)


menubar = Gtk::MenuBar.new

filemenu = Gtk::Menu.new
editmenu = Gtk::Menu.new

file = Gtk::MenuItem.new("消费机测试")
edit = Gtk::MenuItem.new("考勤机/门禁测试")
#help = Gtk::MenuItem.new("Help")

file.submenu = filemenu
edit.submenu = editmenu
#help.submenu = helpmenu

menubar.append(file)
menubar.append(edit)
#menubar.append(help)

menuitem_black_sequence_query = Gtk::MenuItem.new("黑名单序号查询")
filemenu.append(menuitem_black_sequence_query)

menuitem_black_sequence_syn = Gtk::MenuItem.new("黑名单同步")
filemenu.append(menuitem_black_sequence_syn)


filemenu.append(menuitem_cfg = Gtk::MenuItem.new("配置"))


filemenu.append(menuitem_ack = Gtk::MenuItem.new("设置应答参数"))


# Create the Edit menu content.

# Create the Help menu content.

#contents = Gtk::ImageMenuItem.new(Gtk::Stock::HELP, group)
#about    = Gtk::ImageMenuItem.new(Gtk::Stock::ABOUT, group)
#helpmenu.append(contents)
#helpmenu.append(about)

#window.add_accel_group(group)
#file_window.add(menubar)


notebook = Gtk::Notebook.new
#prev_pg = Gtk::Button.new("_Previous Tab")
#close   = Gtk::Button.new("_Close")
#prev_pg.signal_connect( "clicked" ) { prev_tab(notebook) }
#close.signal_connect( "clicked" ) { Gtk.main_quit }


textview = Gtk::TextView.new

scrolled_win = Gtk::ScrolledWindow.new
scrolled_win.border_width = 5
scrolled_win.add(textview)
scrolled_win.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_ALWAYS)

normal_view =  Gtk::TextView.new
normal_win = Gtk::ScrolledWindow.new
normal_win.border_width = 5
normal_win.add(normal_view)
normal_win.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_ALWAYS)



notebook.append_page(scrolled_win, Gtk::Label.new("握手信息"))
notebook.append_page(normal_win, Gtk::Label.new("其他信息"))

vbox = Gtk::VBox.new(false, 5)
vbox.pack_start(menubar, false, false, 0)
vbox.pack_start(notebook, true, true, 0)

window.add(vbox)
window.show_all

menuitem_black_sequence_query.signal_connect("activate") do
  $queue_from_user.enq({:message => "BlackSequenceQuery"})
end

menuitem_ack.signal_connect("activate") do
  dialog = Gtk::Dialog.new(
          "请输入参数",
          window,
          Gtk::Dialog::DESTROY_WITH_PARENT,
          [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ]
  )
  dialog.has_separator = false

  contents = []
  contents << {:name => "签到应答批次号", :para => "sign_in_ack_seq", :default => "1"}
  contents << {:name => "联机批结算应答0成功/1失败", :para => "approved_settlement_ack", :default => "1"}

  contents.each do |content|
    label = Gtk::Label.new("#{content[:name]}: ")
    eval("@#{content[:para]} =  Gtk::Entry.new")
    eval("@#{content[:para]}.text = '#{content[:default]}' ") if  content[:default]

    hbox = Gtk::HBox.new(false, 1)
    hbox.border_width = 1
    hbox.pack_start_defaults(label);
    eval "hbox.pack_start_defaults(@#{content[:para]})"
    dialog.vbox.add(hbox)
  end

  dialog.show_all
  dialog.run do |response|
    case response
      when Gtk::Dialog::RESPONSE_OK
        $pos_ack_cfg[:sign_in_seq] = @sign_in_ack_seq.text.to_i
        $pos_ack_cfg[:approved_settlement_ack] = @approved_settlement_ack.text.to_i
      else

    end

  end
  dialog.destroy
end


menuitem_cfg.signal_connect("activate") do
  dialog = Gtk::Dialog.new(
          "请输入参数",
          window,
          Gtk::Dialog::DESTROY_WITH_PARENT,
          [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ]
  )
  dialog.has_separator = false


  contents = []

  contents << {:name => "设备IP", :para => "dev_ip", :default => "10.86.10.238"}
  contents << {:name => "设备掩码", :para => "dev_mask", :default => '255.255.255.0'}
  contents << {:name => "设备网关", :para => "dev_gw", :default => "10.86.10.1"}
  contents << {:name => "服务器IP", :para => "svr_ip", :default => "10.86.10.12"}
  contents << {:name => "服务器端口", :para => "svr_port", :default => 8080}
  contents << {:name => "设备ID", :para => "wReaderDevID", :default => 216}
  contents << {:name => "企业ID", :para => "company_id", :default => "01000000002a"}
  contents << {:name => "脱机0/联机1", :para => "online_type", :default => "1"}
  contents << {:name => "应用类型标识", :para => "app_type_id", :default => "0"}
  contents << {:name => "发卡方标识", :para => "issue_id", :default => "D156000101000000"}
  contents << {:name => "发卡方应用版本", :para => "issue_app_ver", :default => "0"}
  contents << {:name => "所有子应用个数", :para => "all_subapp_nr", :default => "4"}
  contents << {:name => "所有计费子应用个数", :para => "money_subapp_nr", :default => "2"}
  contents << {:name => "单笔最大钱数", :para => "max_money", :default => "500"}
  contents << {:name => "单笔最大次数", :para => "max_count", :default => "200"}
  contents << {:name => "子应用索引号", :para => "subapp_indexes", :default => "01020304"}


  contents.each do |content|
    label = Gtk::Label.new("#{content[:name]}: ")
    eval("@#{content[:para]} =  Gtk::Entry.new")
    eval("@#{content[:para]}.text = '#{content[:default]}' ") if  content[:default]

    hbox = Gtk::HBox.new(false, 1)
    hbox.border_width = 1
    hbox.pack_start_defaults(label);
    eval "hbox.pack_start_defaults(@#{content[:para]})"
    dialog.vbox.add(hbox)
  end

  dialog.show_all
  dialog.run do |response|
    case response
      when Gtk::Dialog::RESPONSE_OK
        @body = T_ReaderConfig.new()


        reader_ip_config = T_ReaderIPConfig.new()
        @address = T_Address.new

        @address.dwReaderIPAddr = IPAddr.new(@dev_ip.text).to_i
        @address.dwReaderIPMask = IPAddr.new(@dev_mask.text).to_i
        @address.wReaderGateWayNum = 1

        change_item("@address", "dwReaderGateWay", 0, nil, IPAddr.new(@dev_gw.text).to_i)

        reader_ip_config.tAddress = @address

        change_item("@body", "atReaderIPConfig", 0, "tAddress", "@address")

        @body.wReaderDevID = @wReaderDevID.text.to_i

        mw_ip = T_MWIP.new
        mw_ip.dwMWIP = IPAddr.new(@svr_ip.text).to_i
        mw_ip.wMWPort = @svr_port.text.to_i

        @body.tMWIP = mw_ip

        pos_param_cfg = T_PosParamConfig.new
        pos_param_cfg.aucCompanyID = hex_str2hex_octets(@company_id.text)
        pos_param_cfg.ucPosPurchaseType = @online_type.text.to_i
        pos_param_cfg.ucSysType =  @app_type_id.text.to_i
        pos_param_cfg.aucIdentifier  = hex_str2hex_octets(@issue_id.text)
        pos_param_cfg.ucVersionNum =  @issue_app_ver.text.to_i
        pos_param_cfg.ucSubAppCount = @all_subapp_nr.text.to_i
        pos_param_cfg.ucMSubAppCount = @money_subapp_nr.text.to_i
        pos_param_cfg.dwConsumeLimit = @max_money.text.to_i
        pos_param_cfg.dwCountLimit = @max_count.text.to_i
        pos_param_cfg.aucSubAppIndex = hex_str2hex_octets(@subapp_indexes.text)


        @body.tPosParamConfig = pos_param_cfg

        $queue_from_user.enq({:message => "PosConfig", :body => @body})
      else

    end

  end
  dialog.destroy
end


menuitem_black_sequence_syn.signal_connect("activate") do
  dialog = Gtk::Dialog.new(
          "请输入参数",
          window,
          Gtk::Dialog::DESTROY_WITH_PARENT,
          [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ]
  )
  dialog.has_separator = false


  contents = []

  contents << {:name => "黑名单序列号", :para => "black_list_seq", :default => 1}
  contents << {:name => "增加1/删除0", :para => "add_or_del", :default => 1}
  contents << {:name => "黑名单数", :para => "black_list_number", :default => 2}
  contents << {:name => "结束1/未结束0", :para => "is_over", :default => 1}

  20.times do |time|
    contents << {:name => "卡号#{time}", :para => "black_list_card#{time}"}
  end

  contents.each do |content|
    label = Gtk::Label.new("#{content[:name]}: ")
    eval("@#{content[:para]} =  Gtk::Entry.new")
    eval("@#{content[:para]}.text = '#{content[:default]}' ") if  content[:default]

    hbox = Gtk::HBox.new(false, 1)
    hbox.border_width = 1
    hbox.pack_start_defaults(label);
    eval "hbox.pack_start_defaults(@#{content[:para]})"
    dialog.vbox.add(hbox)
  end

  dialog.show_all
  dialog.run do |response|
    case response
      when Gtk::Dialog::RESPONSE_OK
        @body = T_BlackListSyn.new()

        begin
          @body.dwBlackListSynSequence = @black_list_seq.text.to_i
          @body.ucIsAdd = @add_or_del.text.to_i
          @body.ucCount = @black_list_number.text.to_i
          @body.wIsOver = @is_over.text.to_i

          @black_list_number.text.to_i.times do |time|
            temp = T_BlackList.new
            eval "@card_id =  @black_list_card#{time}.text"
            change_item("@body", "atBlackList", time, "aucAppSequence", '@card_id.gsub(/../) {|s|  s + ":"}')
          end
        rescue
          puts $!
        end
        $queue_from_user.enq({:message => "BlackSequenceSyn", :body => @body})
      else

    end

  end
  dialog.destroy
end
#create thread
Thread.new do
  while true
    if message = $queue_keep_alive.deq()
      textview.buffer.text  <<= Time.new.strftime("[%H:%M:%S] ") << message
    end


  end
end

Thread.new do
  while true
    if message = $queue_normal_message.deq()
      normal_view.buffer.text  <<= Time.new.strftime("[%H:%M:%S] ") << message
    end
  end
end


Thread.new do
  while true
    if message = $queue_device_answer.deq()
      dialog = Gtk::MessageDialog.new(
              window,
              Gtk::Dialog::MODAL,
              Gtk::MessageDialog::INFO,
              Gtk::MessageDialog::BUTTONS_OK,
              "#{message}"
      )
      dialog.title = "设备应答"
      dialog.run
      dialog.destroy
    end
  end
end


Gtk.main