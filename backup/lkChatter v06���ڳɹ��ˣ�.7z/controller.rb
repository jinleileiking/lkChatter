require 'lib'

def process_receive_message(client_ip, content)
  content = content.chomp
  if content == "type=keepalive"
    $log.info "#{client_ip}: Keep alive!"
  end
end



#Receive thread
Thread.new do
  receive_socket = UDPSocket.new
  receive_socket.bind(IPSocket.getaddress(Socket.gethostname), PORT)
  while true
    IO.select([receive_socket])
    content, address = receive_socket.recvfrom_nonblock(1024)
    client_ip = address[3]
    $log.info "Receive from: #{client_ip} : #{content}"
    process_receive_message(client_ip, content)
  end
end

#Send Thread
#Thread.new do
#  ips = get_addresses(IPSocket.getaddress(Socket.gethostname))
#
#  while true
#    ips.each do |dest_ip|
#      next if dest_ip == IPSocket.getaddress(Socket.gethostname)
#      send_socket = UDPSocket.new
#      send_socket.connect(dest_ip, PORT)
#      send_socket.send "type=keepalive\r\n", 0
##    dest_ip = send_socket.peeraddr[3]
##    send_socket.close
##    puts "send keep alive to #{dest_ip}"
##    $log.debug "send keep alive to #{dest_ip}"
#    end
#    sleep(5)
#  end
#
#end

while true

end


#require "view"

