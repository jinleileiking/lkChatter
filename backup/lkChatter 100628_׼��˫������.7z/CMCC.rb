require 'lib'

class CMCC < BitStruct
  unsigned    :wMagic, 2 * 8, "wMagic"
  unsigned    :ucSenderPno, 1 * 8, "ucSenderPno"
  unsigned    :ucReceiverPno, 1* 8, "ucReceiverPno"
  unsigned    :wDevID, 2* 8, "wDevID"
  unsigned    :wEventId, 2* 8, "wEventId"
  unsigned    :wMsgDataLen, 2* 8, "wMsgDataLen"
  unsigned    :wMsgSequence, 2* 8, "wMsgSequence"
  rest        :body, "Body of CMCC message"


  MAGIC = 0X5AA5
  EVENT_KEEPALIVE_FROM_DEV = 0x040D
  EVENT_KEEPALIVE_FROM_DEV_REPLY = 0x040E
  EVENT_KEEPALIVE_FROM_PC = 0x040D
  EVENT_KEEPALIVE_FROM_PC_REPLY = 0x040E
  EVENT_VERSION = 0x2001
  EVENT_BLACKLIST_SEQUENCE_QUERY = 0X2203
  EVENT_BLACKLIST_SEQUENCE_QUERY_REPLY = 0X3202
  EVENT_BLACKLIST_SYN_REQUEST = 0x1101
  EVENT_BLACKLIST_SYN = 0X2202
  EVENT_BLACKLIST_SYN_REPLY = 0X3204
  EVENT_CONFIG = 0x2301
  EVENT_CONFIG_REPLY = 0x2302
  EVENT_SIGNED_IN = 0x1107
  EVENT_SIGNED_IN_REPLY = 0x2106
  EVENT_SIGNED_OUT = 0x1108
  EVENT_SIGNED_OUT_REPLY = 0x2107
  EVENT_APPROVED_SETTLEMENT = 0x3205
  EVENT_APPROVED_SETTLEMENT_REPLY = 0x2206
  EVENT_BATCH_REPORT = 0x3203
  EVENT_BATCH_REPORT_REPLY = 0x2205

  def make_frame(event_id, body, link, args)

    self.ucReceiverPno = 0
    self.ucReceiverPno =0

    if args and args.is_a?(Hash) then
      if args[:add_sequence] == :true then
        link.sequence += 1
      end
      if args[:pno] then
        self.ucReceiverPno = args[:pno]
      end
      if args[:sno] then
        self.ucSenderPno = args[:sno]
      end
    end

    self.wMagic =MAGIC
    self.wDevID = link.device_id
    self.wEventId = event_id
    self.wMsgDataLen = body.length
    self.wMsgSequence = link.sequence
    self.body = body

  end


  def check_header
    if self.wMagic != MAGIC
      $log.error 'wrong magic!'
      return
    end

    #check body length
    if (self.body.length < self.wMsgDataLen)  then
      $log.error "Msg Body is shorter than wMsgDataLen"
      return
    end
    # modify body according to the length
    if (self.body.length > self.wMsgDataLen)  then
      $log.info self.body.length
      $log.info self.wMsgDataLen
      self.body = self.body.slice(0..(self.wMsgDataLen - 1))
      $log.info "Msg Body is Longer than wMsgDataLen..cutting.."
    end
  end

  def get_message()
    check_header
    yield self.wEventId
  end

  def proc_ver(link)
    if link.device_id
      $log.error "version has already received!!"
      return
    end

    if self.body != "\000\000\000\001"
      $log.error "version body error"
      return
    end

    link.device_id = self.wDevID

    $queue_normal_message.enq("<-- 版本信息, 设备ID为#{self.wDevID}, 启动PC握手进程!" + "\r\n")
    # 5s内收到keepalive应答，需要重发
    # 5s内收到正常通信报文，重新计时
    # 5s内无应答，重复发送，定时器++
    link.keepalive_timer = Timer.new(5) do
      if link.keepalive_timer.timeout_time >= 2
        $queue_keep_alive.enq("!!! Keep Alive from PC timeout\r\n")
        $log.error "Keep Alive from PC timeout!"
      end
      msg = CMCC.new
      msg.make_frame(EVENT_KEEPALIVE_FROM_PC, '', link,
                     :sno => 5, :pno => 5)
      link.send msg
      $log.debug "--> KeepAlive PC Start"
      $queue_keep_alive.enq("--> 心跳请求(PC发起)\r\n")
    end
    link.keepalive_timer.start
    return
  end

  def last_message_ok?(link, cmd)
    unless link.last_command == cmd
      $queue_device_answer.enq("上一条命令不是本应答的相应命令" )
      false
      return
    end
    true
  end

  def proc_message(msg, link)
    #     puts "0x" + msg.to_s(16)
    if msg == EVENT_VERSION then
      proc_ver(link)
      return
    end

    unless link.device_id   then
      $log.error "version not receive"
      return
    end

    if msg ==  EVENT_KEEPALIVE_FROM_DEV
      $queue_keep_alive.enq("<-- 心跳请求(设备发起)\r\n")

      #make frame
      msg = CMCC.new
      msg.make_frame(EVENT_KEEPALIVE_FROM_DEV_REPLY, '', link, :sno => 5, :pno => 5)
      link.sock.print msg
      $log.debug "--> KeepAlive Dev Start Reply"
      $queue_keep_alive.enq("--> 心跳应答(设备发起)\r\n")
    elsif msg == EVENT_KEEPALIVE_FROM_PC_REPLY
      $queue_keep_alive.enq("<-- 心跳应答(PC发起)\r\n")
      link.keepalive_timer.reset
    elsif msg == EVENT_BLACKLIST_SYN_REQUEST
      content = T_BlackListSynQuestAck.new(self.body)
      $queue_normal_message.enq("<-- POS黑名单同步请求: 企业ID:#{content.aucCompanyID}, 终端号:#{content.aucPosNum}\r\n" )
      link.keepalive_timer.reset
    elsif msg == EVENT_BLACKLIST_SEQUENCE_QUERY_REPLY
      return unless last_message_ok?(link, EVENT_BLACKLIST_SEQUENCE_QUERY)
      link.keepalive_timer.reset
      $queue_normal_message.enq("<-- POS黑名单序列号查询应答" + dump_hex(self.body.unpack("H*")[0]) + "\r\n")
      $queue_device_answer.enq("设备返回" + dump_hex(self.body.unpack("H*")[0]))
    elsif msg == EVENT_BLACKLIST_SYN_REPLY
      $queue_normal_message.enq("<-- POS黑名单同步应答" +  dump_hex(self.body.unpack("H*")[0]) + "\r\n")
      return unless last_message_ok?(link, EVENT_BLACKLIST_SYN)
      link.keepalive_timer.reset
      $queue_device_answer.enq("设备返回" + dump_hex(self.body.unpack("H*")[0]) + "\r\n")
    elsif msg == EVENT_CONFIG_REPLY
      $queue_normal_message.enq("<-- POS配置应答" +  dump_hex(self.body.unpack("H*")[0]) + "\r\n")
      return unless last_message_ok?(link, EVENT_CONFIG)
      link.keepalive_timer.reset
      $queue_device_answer.enq("设备返回" +  dump_hex(self.body.unpack("H*")[0]))
    elsif msg == EVENT_SIGNED_IN
      $queue_normal_message.enq("<-- POS签到" + "\r\n")
      link.keepalive_timer.reset
      msg = CMCC.new
      sign_in_ack = T_SignQuestAck.new
      sign_in_ack.dwBatchSeq = $pos_ack_cfg[:sign_in_seq]
      msg.make_frame(EVENT_SIGNED_IN_REPLY, sign_in_ack, link,
                     :add_sequence => :true, :pno =>4)
      link.sock.print msg
      $queue_normal_message.enq("--> POS签到应答, 返回批次号:#{$pos_ack_cfg[:sign_in_seq]}\r\n")
#      $queue_device_answer.enq("设备签到, 返回批次号:#{$pos_ack_cfg[:sign_in_seq]}")
    elsif msg == EVENT_SIGNED_OUT
      $queue_normal_message.enq("<-- POS签退" + "\r\n")
      link.keepalive_timer.reset
      msg = CMCC.new
      sign_out_ack = T_SignBackQuestAck.new
      msg.make_frame(EVENT_SIGNED_OUT_REPLY, sign_out_ack, link,
                     :add_sequence => :true, :pno =>4
      )
      link.sock.print msg
      $queue_normal_message.enq("--> POS签退应答 返回成功" + "\r\n")
#      $queue_device_answer.enq("设备签退 返回成功")
    elsif msg == EVENT_APPROVED_SETTLEMENT
      content = T_BatchAccount.new(self.body)
      $queue_normal_message.enq("<-- POS批结算:" +
              "结算批次号:#{content.dwBatchAccoutSeq}," +
              "结算净金额:#{content.dwBatchAccount}," +
              "结算净次数:#{content.dwBatchCountNo}," +
              "结算总笔数(计次+金额(包括撤销)):#{content.dwBatchRecordNo}\r\n")

      msg = CMCC.new
      approved_settlement_ack = T_BatchAccountAck.new
      approved_settlement_ack.dwBatchAccoutSeq = $pos_ack_cfg[:sign_in_seq]
      approved_settlement_ack.dwResult = $pos_ack_cfg[:approved_settlement_ack]
      msg.make_frame(EVENT_APPROVED_SETTLEMENT_REPLY, approved_settlement_ack, link,
                     :add_sequence => :true, :pno =>4
      )
      link.sock.print msg
      if $pos_ack_cfg[:approved_settlement_ack] == 0
        $queue_normal_message.enq("--> POS批结算 返回成功" + "\r\n")
      else
        $queue_normal_message.enq("--> POS批结算 返回失败" + "\r\n")
      end
    elsif msg == EVENT_BATCH_REPORT
      content = T_BatchTradeReporting.new(self.body)
      $queue_normal_message.enq("<-- POS批上送:" +
              "流水号:#{content.dwBatchTradeRecordSeq}," +
              "记录个数:#{content.ucTradeDetailCount}," +
              "本次上报是否结束:(1结束):#{content.ucIsOver}," +
              "\r\n")
      content.ucTradeDetailCount.times do |pos|
        trade_record  = content.atTradeDetail[pos].value

#        tmp = "交易记录#{pos}"
#        $queue_normal_message.enq "%40s:%-40s\r\n" % [tmp, '']
#        $queue_normal_message.enq "%40s:%-40d\r\n" % ["流水号", trade_record.dwTradeSeq]
#        $queue_normal_message.enq "%40s:%-40s\r\n" % ["应用序列号", trade_record.aucAppSequence]
#        $queue_normal_message.enq "%40s:%-40s\r\n" % ["终端机编号", trade_record.aucPosNum]
#        $queue_normal_message.enq "%40s:%-40d\r\n" % ["子应用索引号", trade_record.ucSubAppIndex]
#        $queue_normal_message.enq "%40s:%-40d\r\n" % ["金额类型(1次2费)", trade_record.ucMoneyType]
#        $queue_normal_message.enq "%40s:%-40d\r\n" % ["金额/次数", trade_record.dwTradeAmount ]
#        $queue_normal_message.enq "%40s:%-40s\r\n" % ["日期", trade_record.aucTradeDate]
#        $queue_normal_message.enq "%40s:%-40s\r\n" % ["时间", trade_record.aucTradeTime]
#        $queue_normal_message.enq "%40s:%-40d\r\n" % ["类型", trade_record.ucTradeType]
#        $queue_normal_message.enq "%40s:%-40s\r\n" % ["TAC", trade_record.aucTAC]
        $queue_normal_message.enq("    交易记录#{pos}:" +
                "流水号　　　　　:%-6d" % trade_record.dwTradeSeq  +
                "应用序列号:%-30s" % trade_record.aucAppSequence +
                "终端机编号:%-20s" % trade_record.aucPosNum +
                "子应用索引号:%-4d" % trade_record.ucSubAppIndex +
                "金额类型(1次2费):%-20d" % trade_record.ucMoneyType +
                "\r\n")
        $queue_normal_message.enq(
                "    　　　　  " +
                "数额　　　　　　 %-6d" %trade_record.dwTradeAmount  +
                "日期　　　:%-30s" %trade_record.aucTradeDate  +
                "时间　　　:%-20s" %trade_record.aucTradeTime  +
                "类型　　　　:%-4d" %trade_record.ucTradeType  +
                "TAC　　　　　　 :%-20s" %trade_record.aucTAC  +
                "\r\n")
      end


      msg = CMCC.new
      batch_report_ack = T_BatchTradeReportingAck.new
      batch_report_ack.dwResult = 0
      batch_report_ack.dwBatchTradeRecordSeq = content.dwBatchTradeRecordSeq
      msg.make_frame(EVENT_BATCH_REPORT_REPLY, batch_report_ack, link,
                     :add_sequence => :true, :pno =>4
      )
      link.sock.print msg
      $queue_normal_message.enq("--> POS批上送应答 返回成功，序号#{content.dwBatchTradeRecordSeq}" + "\r\n")
    else
      $queue_normal_message.enq "错误的消息号:#{dump_hex(self.wEventId)}\r\n"
    end
  end

end