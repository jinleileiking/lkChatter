require 'lib'

@alive_ips = []
@nicknames = []

def process_receive_message(client_ip, content)
  pattern = /type=keepalive&nickname=(\w+)/
  pattern =~ content.strip
  data = Regexp.last_match
  if data
    $log.info "#{client_ip}: Keep alive! from user: #{data[1]}"
    process_keepalive client_ip, data[1]
  end

  pattern = /nickname=(\w+)&message=(.+)/
  pattern =~ content.strip
  data = Regexp.last_match
  if data
    $log.info "#{client_ip}: Message: #{data[2]} from #{data[1]}"
    process_message client_ip, data[1], data[2]
  end

end

def process_message(client_ip, nickname, message)
  #update user alive view
  $text_show_queue.enq "#{Time.new.strftime("[%H:%M:%S]")}#{nickname}: #{message}"

  #如果ips没有，则天添加此ip
  @alive_ips = @alive_ips << client_ip
  @alive_ips = @alive_ips.uniq

  #udpate nickname view
  @nicknames <<= nickname
  @nicknames = @nicknames.uniq
end

def process_keepalive(client_ip, nickname)
  #store alive ips
  @alive_ips << client_ip
  @alive_ips = @alive_ips.uniq
  
  #update user alive view
  @nicknames <<= nickname
  @nicknames = @nicknames.uniq
end

#Receive thread
Thread.new do
  receive_socket = UDPSocket.new
  receive_socket.bind(IPSocket.getaddress(Socket.gethostname), PORT)
  while true
    IO.select([receive_socket])
    content, address = receive_socket.recvfrom_nonblock(1024)
    client_ip = address[3]
    content = content.chomp
    $log.debug "Receive from: #{client_ip} : #{content}"
    process_receive_message(client_ip, content)
  end
end


#nickname update
Thread.new do
  while true
    #update nicknames
    $log.debug "enq nickname : #{@nicknames.inspect}"
    $nickname_queue.enq(@nicknames)
    sleep(10)
  end
end


#Keepalive Thread
Thread.new do
  ips = get_addresses(IPSocket.getaddress(Socket.gethostname))

  while true
    ips.each do |dest_ip|
      next if dest_ip == IPSocket.getaddress(Socket.gethostname)
      send_socket = UDPSocket.new
      send_socket.connect(dest_ip, PORT)
      send_socket.send "type=keepalive&nickname=#{$user_info.nickname}\r\n", 0
#    dest_ip = send_socket.peeraddr[3]
#      send_socket.close
#      puts "send keep alive to #{dest_ip}"
#      $log.debug "send keep alive to #{dest_ip}"
#      sleep(0.5)
    end
    sleep(5)
  end

end

#send thread
Thread.new do
  while true
    #get message
    if message = $send_queue.deq
      @alive_ips.each do |dest_ip|
        send_socket = UDPSocket.new
        send_socket.connect(dest_ip, PORT)
        send_socket.send message, 0
      end
    end
  end
end


#while true
#  $send_queue.enq("message=I want to say\r\n")
#  sleep 5
#end


require "view"

