class UserInfo
  attr_accessor :nickname

  def initialize
    @nickname = "leiking"
  end
end
