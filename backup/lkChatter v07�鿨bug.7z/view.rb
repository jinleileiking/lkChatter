require "lib"

window = Gtk::Window.new(Gtk::Window::TOPLEVEL)
window.set_title  "群聊工具--By 伟大的leiking"
window.border_width = 10
window.signal_connect('delete_event') { Gtk.main_quit }
window.set_size_request(800, 600)


menubar = Gtk::MenuBar.new
filemenu = Gtk::Menu.new
file = Gtk::MenuItem.new("配置")
file.submenu = filemenu
menubar.append(file)
filemenu.append(menuitem_config = Gtk::MenuItem.new("配置"))


notebook = Gtk::Notebook.new
#prev_pg = Gtk::Button.new("_Previous Tab")
#close   = Gtk::Button.new("_Close")
#prev_pg.signal_connect( "clicked" ) { prev_tab(notebook) }
#close.signal_connect( "clicked" ) { Gtk.main_quit }


textview = Gtk::TextView.new

scrolled_win = Gtk::ScrolledWindow.new
scrolled_win.border_width = 5
scrolled_win.add(textview)
scrolled_win.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_ALWAYS)

notebook.append_page(scrolled_win, Gtk::Label.new("聊天信息"))

say =  Gtk::Entry.new
say.text = "hello"

renderer = Gtk::CellRendererText.new
column = Gtk::TreeViewColumn.new("在线用户", renderer, "text" => 0)
treeview = Gtk::TreeView.new
treeview.append_column(column)

store = Gtk::ListStore.new(String)



# Add the tree model to the tree view
treeview.model = store

userinfo_win = Gtk::ScrolledWindow.new
userinfo_win.add(treeview)
userinfo_win.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC)
userinfo_win.set_size_request(100, 0)

hbox = Gtk::HBox.new(false, 1)
hbox.pack_start(notebook, true, true, 0)
hbox.pack_start(userinfo_win, false, false, 1)

vbox = Gtk::VBox.new(false, 5)
vbox.pack_start(menubar, false, false, 0)
vbox.pack_start(hbox, true, true, 0)
vbox.pack_start(say, false, false, 0)

window.add(vbox)
window.show_all


say.signal_connect("activate") do
  $send_queue.enq "nickname=#{$user_info.nickname}&message=#{say.text}\r\n"
  textview.buffer.text <<= "#{Time.new.strftime("[%H:%M:%S]")}我: #{say.text}\r\n"
  say.text = ''
end

Thread.new do
  while true
    if message = $nickname_queue.deq
      #clear the nickname
      store = store.clear
      $log.debug "get message #{message.inspect}"
      message.each do |nickname|
        iter = store.append
        store.set_value(iter, 0, nickname)
      end
    end
  end
end

Thread.new do
  while true
    if message = $text_show_queue.deq
      textview.buffer.text <<= message
    end

  end
end

menuitem_config.signal_connect("activate") do
  dialog = Gtk::Dialog.new(
          "请输入参数",
          window,
          Gtk::Dialog::DESTROY_WITH_PARENT,
          [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ]
  )
  dialog.has_separator = false

  contents = []
  contents << {:name => "昵称", :para => "nickname", :default => "unknown"}

  contents.each do |content|
    label = Gtk::Label.new("#{content[:name]}: ")
    eval("@#{content[:para]} =  Gtk::Entry.new")
    eval("@#{content[:para]}.text = '#{content[:default]}' ") if  content[:default]

    hbox = Gtk::HBox.new(false, 1)
    hbox.border_width = 1
    hbox.pack_start_defaults(label);
    eval "hbox.pack_start_defaults(@#{content[:para]})"
    dialog.vbox.add(hbox)
  end

  dialog.show_all
  dialog.run do |response|
    case response
      when Gtk::Dialog::RESPONSE_OK
        $user_info.nickname = @nickname.text
      else

    end

  end
  dialog.destroy
end

Gtk.main