Thread.abort_on_exception = true

PORT = 2122

require 'log4r'
include Log4r
$log = Logger.new ''
$log.outputters = Outputter.stdout
$log.level = DEBUG


$send_queue = Queue.new
$text_show_queue = Queue.new
$user_info = UserInfo.new
$nickname_queue = Queue.new